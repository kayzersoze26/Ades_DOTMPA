function Z=getconstraints(fnonlin,u)
% Penalty constant >> 1
PEN=10^15;
% PEN=10^5;
lam=PEN; lameq=PEN;

Z=0;
% Get nonlinear constraints
[g,geq]=fnonlin(u);

% Apply all inequality constraints as a penalty function 
for k=1:length(g),
    Z=Z+ lam*g(k)^2*getH(g(k));
     % Z=Z+ lam*g(k)*getH(g(k));
end
% Apply all equality constraints (when geq=[], length->0)
for k=1:length(geq),
   Z=Z+lameq*geq(k)^2*geteqH(geq(k));
   %Z=Z+lameq*geq(k)*geteqH(geq(k));
end