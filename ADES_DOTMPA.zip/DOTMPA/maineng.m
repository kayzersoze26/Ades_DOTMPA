
clc 
clear
close all
tic 

warning off
format long

fhd = @cec19_func;

% switch(problem)
%     case 1
%         LB = -8192;
%         UB =8192;
%         Dim=9;
%     case 2
%         LB =-16384;
%         UB =16384;
%         Dim=16;
%     case 3
%         LB = -4;
%         UB =4;
%         Dim = 18;
%     otherwise
%         LB = -100;
%         UB =100; 
%         Dim=10;
% end
%%
%% Lower and upper bounds 



% %Tension/compression spring design problem
% lb=[0.05 0.25 2];
% ub=[2 1.3 15];



%%Cantilever beam design problem
 lb=[0.01 0.01 0.01 0.01 0.01];
 ub=[100 100 100 100 100];




%%speed reducer problem
%  lb=[2.6 0.7 17 7.3 7.8 2.9 5];
%  ub=[3.6  0.8 28 8.3 8.3 3.9 5.5];




%The crashworthiness design problem

% lb=[0.500000000000000	0.500000000000000	0.500000000000000	0.500000000000000	0.500000000000000	0.500000000000000	0.500000000000000	0.345000000000000	0.345000000000000	-30	-30];
% ub=[1.50000000000000	1.50000000000000	1.50000000000000	1.50000000000000	1.50000000000000	1.50000000000000	1.50000000000000	0.345000000000000	0.345000000000000	30	30];


% %%Optimal design of industrial refrigeration system
% lb=[0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000,0.00100000000000000];
% ub=[5,5,5,5,5,5,5,5,5,5,5,5,5,5];
% FunctionNumber='F1';
%%%G10%%%%%
% lb=[100,1000,1000,10,10,10,10,10];
% ub=[10000,10000,10000,1000,1000,1000,1000,1000];

% lb = [0 0 0 0];
% ub = [100 100 100 5];
problem=1;
Max_iterations=2000;

% newNopar=.1;

% PopSize    = 30; 

dim=length(lb);
fhandle=@cost1;
fnonlin=@constraint1;
% switch(problem)
%     case 1
%         LB = -8192;
%         UB =8192;
%         Dim=9;
%     case 2
%         LB =-16384;
%         UB =16384;
%         Dim=16;
%     case 3
%         LB = -4;
%         UB =4;
%         Dim = 18;
%     otherwise
%         LB = -100;
%         UB =100; 
%         Dim=10;
% end
%         LB = -100;
%         UB =100; 
%         Dim=10;
%     Lband = ones(1, Dim)*(LB);
%     Uband = ones(1, Dim)*(UB);
% lu=[Lband;Uband];




SearchAgents_no=50;
   i=1;

% run=1;
for run=1:1

[EMPA(run),Top_predator_pos(run,:),Convergence_curve(run,:)]=EMPA_eng(SearchAgents_no,Max_iterations,lb,ub,dim,fhandle,fnonlin);
% [classicMPA(run),Top_predator_pos(run,:),Convergence_curve(run,:)]=MPA(SearchAgents_no,Max_iterations,lb,ub,dim,fhandle,fnonlin);


end


