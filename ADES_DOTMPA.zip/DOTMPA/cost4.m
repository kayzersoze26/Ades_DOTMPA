%%The crashworthiness design problem
function f=cost10(y)
f=1.98+4.90*y(1)+6.67*y(2)+6.98*y(3)+4.01*y(4)+1.78*y(5)+2.73*y(7);